/* feedreader.js*/
$(function() {

    describe('RSS Feeds', function() {

        it('are defined', function() {
            expect(allFeeds).toBeDefined();
            expect(allFeeds.length).not.toBe(0);
        });

         //First makes sure that it loops for each feed in the AllFeeds obj. 
         //& then check that each URL is defined & not empty
         it('should have a defined URL & URL is not empty ', function() {
            allFeeds.forEach(function(feed) {
                expect(feed.url).toBeDefined();
                expect(feed.url).not.toBe('');
            });
         });

         it('should have a defined feed name & name is not empty', function() {
         allFeeds.forEach(function(feed) {
            expect(feed.name).toBeDefined();
            expect(feed.name).not.toBe('');
            });
        });
    });

        /* THE MENU TEST SUITE */
        describe('The Menu', function() {

        });

        // Pre-define elements needed for testing hiding/showing of the menu
        var body = document.body;
        var menuIcon = document.querySelector(".menu-icon-link");

        // Make sure the menu is hidden initially
         it('should be hidden by default', function() {
            expect($('body').hasClass('menu-hidden')).toBe(true);
        });

        // Make sure menu icon toggles hide/show on clicking
        it('should toggle hide & show on clicking', function() {
            // if the  menu icon is clicked, expect the menu to appear
             $('.menu-icon-link').click();
            expect($('body').hasClass('menu-hidden')).not.toBe(true);
            // if the icon is clicked again, expect the menu to be hidden
            $('.menu-icon-link').click();
            expect($('body').hasClass('menu-hidden')).toBe(true);      
        });
    
        describe('Initial Entries', function() {
        //Added a beforeEach function and passed 'done' to the callback for
        // asynchronous functionality
        beforeEach(function(done) {
            loadFeed(0, done);
        });
        it('should contain at least a single entry', function(done) {
            var numEntries = document.querySelector(".feed").getElementsByClassName("entry").length;
            expect(numEntries).toBeGreaterThan(0);
            done();
        });
    });
    
        /* New Feed Selection TEST SUITE */
        describe('New Feed Selection', function() {
            var prevFeedSelection;

            beforeEach(function(done) {
            loadFeed(0, function() {
        prevFeedSelection = document.querySelector(".feed").innerHTML;
        loadFeed(1, function() {
          done();
        });
      });
    });

    // Make sure when new feed is loaded using loadFeed function,
    // the content changes
    it("should changes its content", function() {
      var newFeedSelection = document.querySelector(".feed").innerHTML;
      expect(prevFeedSelection).not.toBe(newFeedSelection);
        });
    });
        
}());
