#Feed Reader Testing
This project is a part of Udacity's FEND Nano-Degree, testing the Feed Reader app using Javascript testing framework **`jasmine.js`**.

## How to run
- Click [here](https://github.com/fmatallah/Feed-Reader-Project#) 

### How to run it locally
- Click "Clone in Desktop" / "Download ZIP"
- Open the folder
- Open `index.html` on your preferred browser
- There should be several test results at the bottom of the screen that says "~ 7 specs, ~ 0 failures"
